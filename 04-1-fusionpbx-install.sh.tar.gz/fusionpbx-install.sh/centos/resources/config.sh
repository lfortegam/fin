
# FusionPBX Settings
system_username=admin           # default username admin
system_password=random          # random or as a pre-set value
system_branch=master            # master, stable

# FreeSWITCH Settings
switch_branch=stable            # master, stable
switch_source=false             # true or false
switch_package=true             # true or false

# Database Settings
database_password=random        # random or as a pre-set value
